package com.neosoft.bankservice.service.impl;

import com.neosoft.bankservice.entities.Routes;
import com.neosoft.bankservice.repositories.RoutesRepo;
import com.neosoft.bankservice.service.RoutesService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class RoutesServiceImpl implements RoutesService {
    @Autowired
    private RoutesRepo routesRepo;

    @Override
    public List<Routes> getAllRoutes(int routeId) {
        return routesRepo.findAll();
    }

    @Override
    public Routes save(Routes routes) {
        return routesRepo.save(routes);
    }
}
