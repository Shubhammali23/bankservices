package com.neosoft.bankservice.entities;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.Entity;
import javax.persistence.Id;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Entity
public class Filter {

    @Id
    private int filterId;

    private String name;

    private boolean proxy;

    private boolean encrypted;

    private boolean audit;

    private String encryptionDetailsCryptName;

    private String encryptionDetailsAssociatedData;

    private int encryptionDetailsIterationCount;

    private int encryptionDetailsKeySize;

    private String encryptionDetailsPassword;

    private boolean denyEmptyKey;

    private String emptyKeyStatusCode;

    private int redisRateLimiterRequestedTokens;

    private int redisRateLimiterReplenishRate;

    private int redisRateLimiterBurstCapacity;
}
