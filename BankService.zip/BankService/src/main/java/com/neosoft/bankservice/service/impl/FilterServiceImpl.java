package com.neosoft.bankservice.service.impl;

import com.neosoft.bankservice.entities.Filter;
import com.neosoft.bankservice.repositories.FilterRepo;
import com.neosoft.bankservice.service.FilterService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class FilterServiceImpl implements FilterService {
    @Autowired
    private FilterRepo filterRepo;

    @Override
    public List<Filter> getAllFilter() {
        return filterRepo.findAll();
    }

    @Override
    public Filter save(Filter filter) {
        return filterRepo.save(filter);
    }
}
