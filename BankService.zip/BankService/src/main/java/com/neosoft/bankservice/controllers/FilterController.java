package com.neosoft.bankservice.controllers;

import com.neosoft.bankservice.entities.Filter;
import com.neosoft.bankservice.service.FilterService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/filter")
public class FilterController {
    @Autowired
    private FilterService filterService;

    @GetMapping("/get")
    public List<Filter> getAllFilter() {
        return filterService.getAllFilter();
    }

    @PostMapping
    public Filter addFilter(@RequestBody Filter filter) {
        return filterService.save(filter);
    }
}
