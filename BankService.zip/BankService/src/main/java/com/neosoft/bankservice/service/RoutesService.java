package com.neosoft.bankservice.service;

import com.neosoft.bankservice.entities.Routes;

import java.util.List;

public interface RoutesService {
    //get routes info

    public List<Routes> getAllRoutes(int routeId);

    public Routes save(Routes routes);
}
