package com.neosoft.bankservice.service;

import com.neosoft.bankservice.entities.Instances;

import java.util.List;

public interface InstanceService {
    //get instance info
    public List<Instances> getAllInstances(String InstanceId);

    public Instances save(Instances instances);
}
