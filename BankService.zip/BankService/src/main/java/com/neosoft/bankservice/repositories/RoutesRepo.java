package com.neosoft.bankservice.repositories;

import com.neosoft.bankservice.entities.Routes;
import org.springframework.data.jpa.repository.JpaRepository;

public interface RoutesRepo extends JpaRepository<Routes, Integer> {
}
