package com.neosoft.bankservice.controllers;

import com.neosoft.bankservice.entities.Routes;
import com.neosoft.bankservice.service.RoutesService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/routes")
public class RoutesController {

    @Autowired
    private RoutesService routesService;


    @GetMapping("/get")
    public List<Routes> getAllRoutes(int routeId) {
        return routesService.getAllRoutes(routeId);
    }

    @PostMapping
    public ResponseEntity<Routes> addRoute(@RequestBody Routes routes) {
        return ResponseEntity.ok(routesService.save(routes));
    }
}
