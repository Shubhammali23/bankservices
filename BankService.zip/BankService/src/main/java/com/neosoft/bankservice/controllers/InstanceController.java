package com.neosoft.bankservice.controllers;


import com.neosoft.bankservice.entities.Instances;
import com.neosoft.bankservice.service.InstanceService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/instance")
public class InstanceController {
    @Autowired
    private InstanceService instanceService;


    @GetMapping("/get")
    public List<Instances> getAllInstances(String instanceId) {
        return instanceService.getAllInstances(instanceId);
    }

    @PostMapping
    public ResponseEntity<Instances> addInstance(@RequestBody Instances instances) {
        return ResponseEntity.ok(instanceService.save(instances));
    }
}
