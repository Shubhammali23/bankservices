package com.neosoft.bankservice.entities;

import com.sun.istack.NotNull;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import java.util.ArrayList;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Entity
public class Routes {

    @Id
    public int routeId;

    public String uriPattern;

    public String uri;
    @Column(columnDefinition = "JSON")
    public String predicates;
    @Column(columnDefinition = "JSON")
    public ArrayList<Filter> filters;


    @Column(columnDefinition = "JSON")
    public String bodyMassagerBean;


    public ArrayList<String> stringFilters;

    public String serviceId;


    @Column(columnDefinition = "JSON")
    public String customRouteDefinition;
    @NotNull
    @Column(columnDefinition = "JSON")
    public String metadata;
    @Column(columnDefinition = "JSON")
    public ArrayList<Instances> instancesForLoadBalance;
}
