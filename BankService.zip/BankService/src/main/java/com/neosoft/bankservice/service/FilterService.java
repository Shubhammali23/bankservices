package com.neosoft.bankservice.service;

import com.neosoft.bankservice.entities.Filter;

import java.util.List;

public interface FilterService {
    //get filter info
    public List<Filter> getAllFilter();

    public Filter save(Filter filter);
}
