package com.neosoft.bankservice.service.impl;

import com.neosoft.bankservice.entities.Instances;
import com.neosoft.bankservice.repositories.InstanceRepo;
import com.neosoft.bankservice.service.InstanceService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class InstanceServiceImpl implements InstanceService {
    @Autowired
    private InstanceRepo instanceRepo;

    @Override
    public List<Instances> getAllInstances(String InstanceId) {
        return instanceRepo.findAll();
    }

    @Override
    public Instances save(Instances instances) {
        return instanceRepo.save(instances);
    }
}
