package com.neosoft.bankservice.entities;

import lombok.*;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;


@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
@Entity
public class Instances {

    @Id
    private String instanceId;

    private String serviceId;

    private String host;

    private int port;

    private boolean secure;

    @Column(columnDefinition = "JSON")
//  private Map<String,String> metadata;
    private String metadata;


}
